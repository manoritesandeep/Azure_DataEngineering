CREATE TABLE [dbo].[NYC_Payroll_AGENCY_MD](
    [AgencyID] [varchar](50) NULL,
    [AgencyName] [varchar](150) NULL
)