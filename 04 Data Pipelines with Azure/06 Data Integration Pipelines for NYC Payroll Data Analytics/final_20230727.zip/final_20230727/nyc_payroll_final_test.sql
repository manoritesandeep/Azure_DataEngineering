SELECT TOP (100) [FiscalYear]
,[AgencyName]
,[TotalPaid]
 FROM [dbo].[NYC_Payroll_Summary]