-- fact_payment table "star schema"

IF NOT EXISTS (SELECT * FROM sys.external_file_formats WHERE name = 'SynapseDelimitedTextFormat') 
    CREATE EXTERNAL FILE FORMAT [SynapseDelimitedTextFormat] 
    WITH ( FORMAT_TYPE = DELIMITEDTEXT ,
           FORMAT_OPTIONS (
             FIELD_TERMINATOR = ',',
             USE_TYPE_DEFAULT = FALSE
            ))
GO;

IF NOT EXISTS (SELECT * FROM sys.external_data_sources WHERE name = 'facttrip_dfs_core_windows_net') 
    CREATE EXTERNAL DATA SOURCE [facttrip_dfs_core_windows_net] 
    WITH (
        LOCATION = 'https://proj02blobacc.blob.core.windows.net/proj02-imports/publicfact_trip'
    )
GO;

/*
IF OBJECT_ID('dbo.fact_trip') IS NOT NULL
BEGIN
    DROP TABLE dbo.fact_trip
END;
*/

CREATE EXTERNAL TABLE dbo.fact_trip
WITH (
    LOCATION     = 'fact_trip',
    DATA_SOURCE = [facttrip_dfs_core_windows_net],
    FILE_FORMAT = [SynapseDelimitedTextFormat]
)  
AS
    SELECT 
        TOP 100
        t.trip_id AS trip_key
        , DATEDIFF(MINUTE, t.start_at, t.ended_at)   AS trip_duration
        , DATEDIFF(YEAR, r.birthday, t.start_at) AS rider_age_at_trip
        , s.station_id as station_key
        , r.rider_id as rider_key
        , cast(FORMAT(p.date,'yyyyMMdd') as int) as date_key
        , t.rideable_type
        , t.start_station_id
        , t.end_station_id
    FROM [dbo].[staging_trip] t
        INNER JOIN [dbo].[staging_rider] r 
            ON r.rider_id = t.rider_id
        INNER JOIN [dbo].[staging_station] s 
            ON t.start_station_id = s.station_id
        INNER JOIN [dbo].[staging_payment] p
            ON t.rider_id = p.rider_id
GO;

SELECT TOP 100 * FROM dbo.fact_trip;