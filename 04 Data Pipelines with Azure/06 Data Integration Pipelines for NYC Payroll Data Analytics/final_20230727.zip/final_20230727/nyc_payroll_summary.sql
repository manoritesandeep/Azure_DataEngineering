CREATE TABLE [dbo].[NYC_Payroll_Summary]( 
    [FiscalYear] [int] NULL,
    [AgencyName] [varchar](50) NULL, 
    [TotalPaid] [float] NULL 
)
GO;