-- fact_payment table "star schema"

IF NOT EXISTS (SELECT * FROM sys.external_file_formats WHERE name = 'SynapseDelimitedTextFormat') 
    CREATE EXTERNAL FILE FORMAT [SynapseDelimitedTextFormat] 
    WITH ( FORMAT_TYPE = DELIMITEDTEXT ,
           FORMAT_OPTIONS (
             FIELD_TERMINATOR = ',',
             USE_TYPE_DEFAULT = FALSE
            ))
GO;

IF NOT EXISTS (SELECT * FROM sys.external_data_sources WHERE name = 'factpayment_dfs_core_windows_net') 
    CREATE EXTERNAL DATA SOURCE [factpayment_dfs_core_windows_net] 
    WITH (
        LOCATION = 'https://proj02blobacc.blob.core.windows.net/proj02-imports/publicfact_payment'
    )
GO;

/*
IF OBJECT_ID('dbo.fact_payment') IS NOT NULL
BEGIN
    DROP TABLE dbo.fact_payment
END;
*/

CREATE EXTERNAL TABLE dbo.fact_payment
WITH (
    LOCATION     = 'fact_payment',
    DATA_SOURCE = [factpayment_dfs_core_windows_net],
    FILE_FORMAT = [SynapseDelimitedTextFormat]
)  
AS
    SELECT 
        p.payment_id as payment_key,
        cast(FORMAT(p.date,'yyyyMMdd') as int) as date_key
        -- CAST(p.date AS DATE) as date_key
        , r.rider_id as rider_key
        , p.amount
    FROM [dbo].[staging_payment] p
    INNER JOIN [dbo].[staging_rider] r ON p.rider_id = r.rider_id

GO;

SELECT TOP 100 * FROM dbo.fact_payment;