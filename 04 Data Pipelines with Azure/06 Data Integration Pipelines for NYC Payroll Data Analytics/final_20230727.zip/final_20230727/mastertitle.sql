CREATE TABLE [dbo].[NYC_Payroll_TITLE_MD](
    [TitleCode] [varchar](50) NULL,
    [TitleDescription] [varchar](250) NULL
)

GO;
